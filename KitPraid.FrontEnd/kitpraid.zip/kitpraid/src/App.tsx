import './App.css'
import { Routes, Route } from 'react-router-dom'
import { Footer } from './components/Footer/Footer'
import Header from './components/Header'
import Home from './pages/Home'
import AuthRoutes from './routes/AuthRoutes'

function App() {
  return (
    <>
      <Header />
      <main className="main-content">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/*" element={<AuthRoutes />} />
        </Routes>
      </main>
      <Footer />
    </>
  )
}

export default App
