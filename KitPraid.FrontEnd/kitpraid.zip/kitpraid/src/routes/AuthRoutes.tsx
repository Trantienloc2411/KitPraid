
import { Routes, Route } from 'react-router-dom';
import {
  SignIn,
  SignUp,
  ForgotPassword,
  ResetPassword,
  EmailVerification,
} from '../pages/Auth';

const AuthRoutes = () => {
  return (
    <Routes>
      <Route path="/signin" element={<SignIn />} />
      <Route path="/signup" element={<SignUp />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route path="/email-verification" element={<EmailVerification />} />
    </Routes>
  );
};

export default AuthRoutes;
